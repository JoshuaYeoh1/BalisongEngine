var classirrklang_1_1_i_file_reader =
[
    [ "getFileName", "classirrklang_1_1_i_file_reader.html#a35b482b7d226feab04984d1cc0ec6b04", null ],
    [ "getPos", "classirrklang_1_1_i_file_reader.html#a99c405529f07b2b0190beda048b432e2", null ],
    [ "getSize", "classirrklang_1_1_i_file_reader.html#af6f0881f2c887cc41016c58144853b5f", null ],
    [ "read", "classirrklang_1_1_i_file_reader.html#a0ba36fc0023d3ad430bbe34770364559", null ],
    [ "seek", "classirrklang_1_1_i_file_reader.html#a1c98718116049833e2de77a67a07faaa", null ]
];