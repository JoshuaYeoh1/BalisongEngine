var classirrklang_1_1_i_audio_recorder =
[
    [ "addSoundSourceFromRecordedAudio", "classirrklang_1_1_i_audio_recorder.html#ab083d7bd622b0bf556357ac927d2dd7f", null ],
    [ "clearRecordedAudioDataBuffer", "classirrklang_1_1_i_audio_recorder.html#a3c45b902520c4bf5610da78476183fb2", null ],
    [ "getAudioFormat", "classirrklang_1_1_i_audio_recorder.html#ac6f664694d15960dff90d9288850c472", null ],
    [ "getDriverName", "classirrklang_1_1_i_audio_recorder.html#a20687dc3b59a4e58ca645eca1a4e02bc", null ],
    [ "getRecordedAudioData", "classirrklang_1_1_i_audio_recorder.html#ad0382678826f8dc93f20970175855083", null ],
    [ "isRecording", "classirrklang_1_1_i_audio_recorder.html#a6b98611df2d840191002479455e73f3e", null ],
    [ "startRecordingBufferedAudio", "classirrklang_1_1_i_audio_recorder.html#ad02c63bf445c6f916e43271c428a05f4", null ],
    [ "startRecordingCustomHandledAudio", "classirrklang_1_1_i_audio_recorder.html#ae1d39c90335b96f95c050fc98c1bfac1", null ],
    [ "stopRecordingAudio", "classirrklang_1_1_i_audio_recorder.html#aa00ecf279dfad147e313acac7a04024b", null ]
];