var classirrklang_1_1_i_sound_device_list =
[
    [ "getDeviceCount", "classirrklang_1_1_i_sound_device_list.html#a546d93bf5e70b5b168c430329194f2e4", null ],
    [ "getDeviceDescription", "classirrklang_1_1_i_sound_device_list.html#ad44d1d082d626221accce41ff5efa38f", null ],
    [ "getDeviceID", "classirrklang_1_1_i_sound_device_list.html#a784ef34e767c31b0251e7d153a97b48b", null ]
];