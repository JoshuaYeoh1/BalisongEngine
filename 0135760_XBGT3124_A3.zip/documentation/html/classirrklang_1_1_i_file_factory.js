var classirrklang_1_1_i_file_factory =
[
    [ "createFileReader", "classirrklang_1_1_i_file_factory.html#ae7c3c339baf595dac66cd693db3ea3b2", null ]
];