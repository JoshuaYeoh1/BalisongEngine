var classirrklang_1_1_i_sound_stop_event_receiver =
[
    [ "~ISoundStopEventReceiver", "classirrklang_1_1_i_sound_stop_event_receiver.html#a26adc3eec345f11286e576e449e6647d", null ],
    [ "OnSoundStopped", "classirrklang_1_1_i_sound_stop_event_receiver.html#a8e975104683b71cd45436ae5f8bfaf9f", null ]
];