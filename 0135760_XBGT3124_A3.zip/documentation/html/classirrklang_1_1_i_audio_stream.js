var classirrklang_1_1_i_audio_stream =
[
    [ "~IAudioStream", "classirrklang_1_1_i_audio_stream.html#ab356024dfcdde9f864cfa7dc9d76e346", null ],
    [ "getFormat", "classirrklang_1_1_i_audio_stream.html#a179a1fc826d94884f9cb3dd4f5e52943", null ],
    [ "getIsSeekingSupported", "classirrklang_1_1_i_audio_stream.html#a4e10ae9405140ec6b4f09422c8c2eaa4", null ],
    [ "readFrames", "classirrklang_1_1_i_audio_stream.html#a09d6d3de70aa95df109f5eb58c799980", null ],
    [ "setPosition", "classirrklang_1_1_i_audio_stream.html#a1ac6276613e91d0f530bfee3cf5f92ff", null ]
];