var classirrklang_1_1_i_virtual_ref_counted =
[
    [ "~IVirtualRefCounted", "classirrklang_1_1_i_virtual_ref_counted.html#a54ed4b2c2bf1fd7666f7d78a9e768612", null ],
    [ "drop", "classirrklang_1_1_i_virtual_ref_counted.html#a6602c3d110f23410c5bca8a08b709aa4", null ],
    [ "grab", "classirrklang_1_1_i_virtual_ref_counted.html#a1720491c5a3a511985903bfa3c829018", null ]
];