var class_balisong_engine_1_1_app_window =
[
    [ "GetNativeWindow", "class_balisong_engine_1_1_app_window.html#adbbe3cdc6ff9e58ae143a665a4a0fe21", null ],
    [ "GetWindowHeight", "class_balisong_engine_1_1_app_window.html#a4bf06bb9a3cd69879b129e9ff56637f7", null ],
    [ "GetWindowWidth", "class_balisong_engine_1_1_app_window.html#adcd13176449cf0be29d4f18064e0d0b0", null ],
    [ "Init", "class_balisong_engine_1_1_app_window.html#a4e97e9bc3661d9201b3d50c3c8364137", null ],
    [ "SetWindowEventCallback", "class_balisong_engine_1_1_app_window.html#a6c9ea38f97056c5808b4e9689527cab9", null ],
    [ "SetWindowHeight", "class_balisong_engine_1_1_app_window.html#ae1dd5fd7cbdd64b4be76c669561615a9", null ],
    [ "SetWindowSize", "class_balisong_engine_1_1_app_window.html#a7052c88fa0bae02cb7163774adb01f02", null ],
    [ "SetWindowWidth", "class_balisong_engine_1_1_app_window.html#a682029e3d8fae3844d6becbd5dc43698", null ],
    [ "Update", "class_balisong_engine_1_1_app_window.html#a966386a9585660ef90955536575b1de6", null ]
];