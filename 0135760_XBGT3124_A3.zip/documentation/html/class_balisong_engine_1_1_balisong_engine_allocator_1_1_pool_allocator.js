var class_balisong_engine_1_1_balisong_engine_allocator_1_1_pool_allocator =
[
    [ "PoolAllocator", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_pool_allocator.html#a3a79b285b46380c59bd3f1499d547c00", null ],
    [ "Allocate", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_pool_allocator.html#aa20edd539217ec65f3fbe0bdca124cb7", null ],
    [ "Deallocate", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_pool_allocator.html#aaba9dae863fa677257db9212e06f4105", null ]
];