var classirrklang_1_1_i_ref_counted =
[
    [ "IRefCounted", "classirrklang_1_1_i_ref_counted.html#ad9d20b84a525d7bc07e44b556fbf7da6", null ],
    [ "~IRefCounted", "classirrklang_1_1_i_ref_counted.html#a7fe8953e57adac9bcd28a94d3b251886", null ],
    [ "drop", "classirrklang_1_1_i_ref_counted.html#a869fe3adc6e49e8da105e95837a565b1", null ],
    [ "grab", "classirrklang_1_1_i_ref_counted.html#a737b09ee717069b964a3bd0451690388", null ]
];