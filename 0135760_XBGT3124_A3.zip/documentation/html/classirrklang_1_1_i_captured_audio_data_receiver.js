var classirrklang_1_1_i_captured_audio_data_receiver =
[
    [ "OnReceiveAudioDataStreamChunk", "classirrklang_1_1_i_captured_audio_data_receiver.html#a1271d74901e6ce1a19f234fc0838c2b1", null ]
];