var class_balisong_engine_1_1_balisong_engine_allocator_1_1_base_resource =
[
    [ "BaseResource", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_base_resource.html#abb207d4608fefc4e8f9196a49c8de399", null ],
    [ "DecrementRef", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_base_resource.html#a2a2726954793569545cb5656d54d5921", null ],
    [ "GetRefCount", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_base_resource.html#a33e1e173e95aebcf8b03417766942dde", null ],
    [ "GetResourceType", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_base_resource.html#a3cc92cb7f7736e66639e5bb977e72687", null ],
    [ "IncrementRef", "class_balisong_engine_1_1_balisong_engine_allocator_1_1_base_resource.html#ac736cbe218483977e30735aeb9971b78", null ]
];